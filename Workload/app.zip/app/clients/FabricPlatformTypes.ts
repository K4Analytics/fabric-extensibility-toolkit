/**
 * TypeScript interfaces for Fabric Platform API data models
 * Based on the platform.json definitions from microsoft/fabric-rest-api-specs
 */

// Authentication configuration types
export interface ServicePrincipalConfig {
  clientId: string;
  clientSecret: string;
  tenantId: string;
  authority?: string; // Optional custom authority URL
}

export interface AuthenticationConfig {
  type: 'UserToken' | 'ServicePrincipal';
  servicePrincipal?: ServicePrincipalConfig;
  customToken?: string; // For pre-acquired tokens
}

// Common types
export interface Principal {
  id: string;
  type: PrincipalType;
  displayName?: string;
  groupDetails?: GroupDetails;
  servicePrincipalDetails?: ServicePrincipalDetails;
  servicePrincipalProfileDetails?: ServicePrincipalProfileDetails;
  userDetails?: UserDetails;
}

export type PrincipalType = 'User' | 'ServicePrincipal' | 'Group' | 'ServicePrincipalProfile';

export interface GroupDetails {
  groupType: GroupType;
}

export type GroupType = 'Unknown' | 'SecurityGroup' | 'DistributionList';

export interface ServicePrincipalDetails {
  aadAppId: string;
}

export interface ServicePrincipalProfileDetails {
  parentPrincipal: Principal;
}

export interface UserDetails {
  userPrincipalName: string;
}

export interface PaginatedResponse<T> {
  value: T[];
  continuationToken?: string;
  continuationUri?: string;
}

// Workspace types
export interface Workspace {
  id: string;
  displayName: string;
  description: string;
  type: WorkspaceType;
  capacityId?: string;
}

export interface WorkspaceInfo extends Workspace {
  capacityAssignmentProgress?: CapacityAssignmentProgress;
  workspaceIdentity?: WorkspaceIdentity;
  capacityRegion?: string;
  oneLakeEndpoints?: OneLakeEndpoints;
}

export interface CreateWorkspaceRequest {
  displayName: string;
  description?: string;
  capacityId?: string;
}

export interface UpdateWorkspaceRequest {
  displayName?: string;
  description?: string;
}

export type WorkspaceType = 'Personal' | 'Workspace';
export type CapacityAssignmentProgress = 'Completed' | 'Failed' | 'InProgress';

export interface WorkspaceIdentity {
  applicationId: string;
  servicePrincipalId: string;
}

export interface OneLakeEndpoints {
  blobEndpoint: string;
  dfsEndpoint: string;
}

// Workspace Role Assignment types
export interface WorkspaceRoleAssignment {
  id: string;
  principal: Principal;
  role: WorkspaceRole;
}

export interface AddWorkspaceRoleAssignmentRequest {
  principal: Principal;
  role: WorkspaceRole;
}

export interface UpdateWorkspaceRoleAssignmentRequest {
  role: WorkspaceRole;
}

export type WorkspaceRole = 'Admin' | 'Member' | 'Contributor' | 'Viewer';

// Capacity types
export interface Capacity {
  id: string;
  displayName?: string;
  sku?: string;
  region?: string;
  state?: CapacityState;
  admins?: string[];
}

export type CapacityState = 'Active' | 'Inactive' | 'Provisioning' | 'Suspended' | 'Paused';

export interface CapacityWorkload {
  name: string;
  state: WorkloadState;
}

export type WorkloadState = 'Enabled' | 'Disabled' | 'Unsupported';

export interface AssignWorkspaceToCapacityRequest {
  workspaceId: string;
}

export interface UnassignWorkspaceFromCapacityRequest {
  workspaceId: string;
}

// Item types
export interface Item {
  id: string;
  type: string;
  displayName: string;
  description?: string;
  workspaceId: string;
  folderId?: string;
  definition?: ItemDefinition;
}

export interface CreateItemRequest {
  displayName: string;
  description?: string;
  type: string;
  folderId?: string;
  definition?: ItemDefinition;
  creationPayload?: Record<string, unknown>;
}

export interface UpdateItemRequest {
  displayName?: string;
  description?: string;
}

export interface ItemDefinition {
  format?: string;
  parts: ItemDefinitionPart[];
}

export interface ItemDefinitionPart {
  path: string;
  payload: string;
  payloadType: PayloadType;
}

export type PayloadType = 'InlineBase64' | 'InlineJson';

export interface ItemDefinitionResponse {
  definition: ItemDefinition;
}

export interface UpdateItemDefinitionRequest {
  definition: ItemDefinition;
}

export interface MoveItemRequest {
  targetFolderId?: string;
}

export interface BulkMoveItemsRequest {
  items: string[];
  targetFolderId?: string;
}

export interface MovedItems {
  value: Item[];
}

// Folder types
export interface Folder {
  id: string;
  displayName: string;
  type: 'Folder';
  workspaceId: string;
  parentFolderId?: string;
}

export interface CreateFolderRequest {
  displayName: string;
  parentFolderId?: string;
}

export interface UpdateFolderRequest {
  displayName: string;
}

export interface MoveFolderRequest {
  targetFolderId?: string;
}

// Job Scheduler types
export interface ItemSchedule {
  id: string;
  enabled: boolean;
  createdDateTime: string;
  configuration: ScheduleConfig;
  owner: Principal;
}

export interface ScheduleConfig {
  type: ScheduleType;
  startDateTime: string;
  endDateTime: string;
  localTimeZoneId: string;
}

export type ScheduleType = 'Cron' | 'Daily' | 'Weekly';

export interface CronScheduleConfig extends ScheduleConfig {
  type: 'Cron';
  interval: number;
}

export interface DailyScheduleConfig extends ScheduleConfig {
  type: 'Daily';
  times: string[];
}

export interface WeeklyScheduleConfig extends ScheduleConfig {
  type: 'Weekly';
  times: string[];
  weekdays: DayOfWeek[];
}

export type DayOfWeek = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';

export interface CreateScheduleRequest {
  enabled: boolean;
  configuration: ScheduleConfig;
}

export interface UpdateScheduleRequest {
  enabled: boolean;
  configuration: ScheduleConfig;
}

export interface ItemJobInstance {
  id: string;
  itemId: string;
  jobType: string;
  invokeType: InvokeType;
  status: JobStatus;
  rootActivityId?: string;
  startTimeUtc?: string;
  endTimeUtc?: string;
  failureReason?: ErrorResponse;
}

export type InvokeType = 'Scheduled' | 'Manual';
export type JobStatus = 'NotStarted' | 'InProgress' | 'Completed' | 'Failed' | 'Cancelled' | 'Deduped';

export interface RunOnDemandItemJobRequest {
  executionData?: Record<string, unknown>;
}

// Long Running Operations
export interface OperationState {
  status: LongRunningOperationStatus;
  createdTimeUtc: string;
  lastUpdatedTimeUtc: string;
  percentComplete?: number;
  error?: ErrorResponse;
}

export type LongRunningOperationStatus = 'Undefined' | 'NotStarted' | 'Running' | 'Succeeded' | 'Failed';

export interface OneLakeStoragePathMetadata {
    contentLength: number;
    lastModified: string;
    creationTime: string;
    permissions: string;
    name: string;
    isShortcut?: boolean;
    accountType?: string;
    isDirectory?: boolean;
}

export interface OneLakeStorageContainerMetadata {
  paths: OneLakeStoragePathMetadata[];
}


// OneLake Shortcuts types
export interface Shortcut {
  path: string;
  name: string;
  target: Target;
  transform?: Transform;
}

export enum ShortcutConflictPolicy {
  Abort = "Abort",
  GenerateUniqueName = "GenerateUniqueName",
  CreateOrOverwrite = "CreateOrOverwrite",
  OverwriteOnly = "OverwriteOnly"
}

export interface CreateShortcutRequest {
  path: string;
  name: string;
  target: CreatableShortcutTarget;
}

export interface CreateShortcutWithTransformRequest extends CreateShortcutRequest {
  transform?: Transform;
}

export interface BulkCreateShortcutsRequest {
  createShortcutRequests: CreateShortcutWithTransformRequest[];
}

export interface Target {
  type: TargetType;
  oneLake?: OneLakeTarget;
  amazonS3?: AmazonS3Target;
  adlsGen2?: AdlsGen2Target;
  googleCloudStorage?: GoogleCloudStorageTarget;
  s3Compatible?: S3CompatibleTarget;
  dataverse?: DataverseTarget;
  externalDataShare?: ExternalDataShareTarget;
  azureBlobStorage?: AzureBlobStorageTarget;
}

export type TargetType = 'OneLake' | 'AmazonS3' | 'AdlsGen2' | 'GoogleCloudStorage' | 'S3Compatible' | 'Dataverse' | 'ExternalDataShare' | 'AzureBlobStorage';

export interface CreatableShortcutTarget {
  oneLake?: OneLakeTarget;
  amazonS3?: AmazonS3Target;
  adlsGen2?: AdlsGen2Target;
  googleCloudStorage?: GoogleCloudStorageTarget;
  s3Compatible?: S3CompatibleTarget;
  dataverse?: DataverseTarget;
  azureBlobStorage?: AzureBlobStorageTarget;
}

export interface OneLakeTarget {
  itemId: string;
  workspaceId: string;
  path: string;
  connectionId?: string;
}

export interface AmazonS3Target {
  location: string;
  subpath?: string;
  connectionId: string;
}

export interface AdlsGen2Target {
  location: string;
  subpath: string;
  connectionId: string;
}

export interface GoogleCloudStorageTarget {
  location: string;
  subpath: string;
  connectionId: string;
}

export interface S3CompatibleTarget {
  location: string;
  subpath: string;
  bucket: string;
  connectionId: string;
}

export interface DataverseTarget {
  environmentDomain: string;
  connectionId: string;
  deltaLakeFolder: string;
  tableName: string;
}

export interface AzureBlobStorageTarget {
  location: string;
  subpath: string;
  connectionId: string;
}

export interface ExternalDataShareTarget {
  connectionId: string;
}

export interface Transform {
  type: TransformType;
}

export type TransformType = 'csvToDelta';

export interface CsvToDeltaTransform extends Transform {
  type: 'csvToDelta';
  properties: CsvToDeltaTransformProperties;
}

export interface CsvToDeltaTransformProperties {
  delimiter?: string;
  useFirstRowAsHeader?: boolean;
  skipFilesWithErrors?: boolean;
}

// Data Access Security types
export interface DataAccessRole {
  id?: string;
  name: string;
  decisionRules: DecisionRule[];
  members?: Members;
}

export interface DecisionRule {
  effect?: Effect;
  permission: PermissionScope[];
}

export type Effect = 'Permit';

export interface PermissionScope {
  attributeName: AttributeName;
  attributeValueIncludedIn: string[];
}

export type AttributeName = 'Path' | 'Action';

export interface Members {
  fabricItemMembers?: FabricItemMember[];
  microsoftEntraMembers?: MicrosoftEntraMember[];
}

export interface MicrosoftEntraMember {
  tenantId: string;
  objectId: string;
  objectType?: ObjectType;
}

export type ObjectType = 'Group' | 'User' | 'ServicePrincipal' | 'ManagedIdentity';

export interface FabricItemMember {
  itemAccess: ItemAccess[];
  sourcePath: string;
}

export type ItemAccess = 'Read' | 'Write' | 'Reshare' | 'Explore' | 'Execute' | 'ReadAll';

export interface CreateOrUpdateDataAccessRolesRequest {
  value: DataAccessRole[];
}

// Error types
export interface ErrorResponse {
  error: {
    code: string;
    message: string;
    details?: ErrorDetail[];
  };
}

export interface ErrorDetail {
  code: string;
  message: string;
  target?: string;
}

export interface AsyncOperationIndicator {
  operationId: string;
  retryAfter?: number;
}


// Enum for batch job states
export enum BatchState {
    STARTING = "starting",
    RUNNING = "running",
    DEAD = "dead",
    SUCCESS = "success",
    KILLED = "killed",
    ERROR = "error",
    NOT_STARTED = "not_started",
    SUBMITTING = "submitting",
    NOT_SUBMITTED = "not_submitted"
}

// Enum for session states
export enum SessionState {
    STARTING = "starting",
    RUNNING = "running",
    IDLE = "idle",
    DEAD = "dead",
    SUCCESS = "success",
    KILLED = "killed",
    ERROR = "error", 
    SHUTTING_DOWN = "shutting_down",
    BUSY = "busy",
    RECOVERING = "recovering",
    NOT_STARTED = "not_started",
    SUBMITTING = "submitting",
    NOT_SUBMITTED = "not_submitted"
}

// Enum for job types
export enum JobType {
    SPARK_BATCH = "SparkBatch",
    SPARK_SESSION = "SparkSession",
    SCOPE_BATCH = "ScopeBatch",
    JUPYTER_ENVIRONMENT = "JupyterEnvironment"
}

// Enum for job results
export enum JobResult {
    UNCERTAIN = "Uncertain",
    SUCCEEDED = "Succeeded",
    FAILED = "Failed",
    CANCELLED = "Cancelled"
}

// Enum for error sources
export enum ErrorSource {
    SYSTEM = "System",
    USER = "User",
    UNKNOWN = "Unknown",
    DEPENDENCY = "Dependency"
}

// Interfaces for batch operations
export interface BatchRequest {
    name?: string;
    file?: string;
    proxyUser?: string;
    className?: string;
    args?: string[];
    jars?: string[];
    pyFiles?: string[];
    files?: string[];
    driverMemory?: string;
    driverCores?: number;
    executorMemory?: string;
    executorCores?: number;
    numExecutors?: number;
    archives?: string[];
    queue?: string;
    conf?: { [key: string]: string };
    maxRetries?: number;
    tags?: { [key: string]: string };
}

export interface BatchStateInformation {
    id?: string;
    appId?: string;
    name?: string;
    workspaceId?: string;
    submitterId?: string;
    submitterName?: string;
    artifactId?: string;
    cancellationReason?: string;
    result?: JobResult;
    submittedAt?: string;
    startedAt?: string;
    endedAt?: string;
    errorSource?: ErrorSource;
    errorCode?: string;
    tags?: { [key: string]: string };
    schedulerState?: string;
    pluginState?: string;
    livyState?: string;
    isJobTimedOut?: boolean;
}

export interface BatchStateInfo {
    state?: string;
    errorMessage?: string;
}

export interface ErrorInformation {
    message?: string;
    errorCode?: string;
    source?: ErrorSource;
}

export interface SparkServicePluginInformation {
    state?: string;
}

export interface SchedulerInformation {
    state?: string;
}

export interface BatchResponse {
    livyInfo?: BatchStateInformation;
    fabricBatchStateInfo?: BatchStateInfo;
    name?: string;
    id?: string;
    appId?: string;
    appInfo?: { [key: string]: string };
    artifactId?: string;
    errorInfo?: ErrorInformation[];
    jobType?: JobType;
    submitterId?: string;
    submitterName?: string;
    log?: string[];
    pluginInfo?: SparkServicePluginInformation;
    schedulerInfo?: SchedulerInformation;
    state?: BatchState;
    tags?: { [key: string]: string };
    result?: JobResult;
    cancellationReason?: string;
}

// Interfaces for session operations
export interface SessionRequest {
    name?: string;
    kind?: string; // e.g., "pyspark", "sparksql", "sparkR"
    proxyUser?: string;
    jars?: string[];
    pyFiles?: string[];
    files?: string[];
    driverMemory?: string;
    driverCores?: number;
    executorMemory?: string;
    executorCores?: number;
    numExecutors?: number;
    archives?: string[];
    queue?: string;
    conf?: { [key: string]: string };
    heartbeatTimeoutInSeconds?: number;
    tags?: { [key: string]: string };
}

export interface LivySessionStateInformation {
    id?: string;
    appId?: string;
    name?: string;
    workspaceId?: string;
    submitterId?: string;
    submitterName?: string;
    artifactId?: string;
    cancellationReason?: string;
    result?: JobResult;
    submittedAt?: string;
    startedAt?: string;
    endedAt?: string;
    errorSource?: ErrorSource;
    errorCode?: string;
    tags?: { [key: string]: string };
    schedulerState?: string;
    pluginState?: string;
    livyState?: string;
    isJobTimedOut?: boolean;
}

export interface SessionStateInfo {
    state?: string;
    errorMessage?: string;
}

export interface SessionResponse {
    fabricSessionStateInfo?: SessionStateInfo;
    livyInfo?: LivySessionStateInformation;
    name?: string;
    id?: string;
    appId?: string;
    appInfo?: { [key: string]: string };
    artifactId?: string;
    errorInfo?: ErrorInformation[];
    jobType?: JobType;
    submitterId?: string;
    submitterName?: string;
    log?: string[];
    pluginInfo?: SparkServicePluginInformation;
    schedulerInfo?: SchedulerInformation;
    state?: SessionState;
    tags?: { [key: string]: string };
    result?: JobResult;
    cancellationReason?: string;
}

// Interfaces for statement operations
export interface StatementRequest {
    code: string;
    kind?: string;
}

export interface StatementOutput {
    status: string;
    execution_count: number;
    data?: any;
}

export interface StatementResponse {
    id: number;
    code: string;
    state: string;
    output?: StatementOutput;
    progress?: number;
    started?: number;
    completed?: number;
}

// Connection types
export interface Connection {
  id: string;
  displayName: string;
  connectivityType: 'ShareableCloud' | 'OnPremisesGateway' | 'VirtualNetworkGateway';
  connectionDetails: {
    type: string;
    path: string;
    [key: string]: any; // Allow additional properties
  };
  privacyLevel: 'None' | 'Private' | 'Organizational' | 'Public';
  credentialDetails: {
    credentialType: string;
    singleSignOnType: 'None' | 'OAuth2' | 'Windows';
    connectionEncryption: 'NotEncrypted' | 'Encrypted';
    skipTestConnection: boolean;
    [key: string]: any; // Allow additional credential properties
  };
  description?: string;
  gatewayId?: string;
  createdDate?: string;
  modifiedDate?: string;
  createdBy?: {
    id: string;
    displayName: string;
    userPrincipalName: string;
  };
  modifiedBy?: {
    id: string;
    displayName: string;
    userPrincipalName: string;
  };
}

export interface CreateConnectionRequest {
  displayName: string;
  connectivityType: 'ShareableCloud' | 'OnPremisesGateway' | 'VirtualNetworkGateway';
  connectionDetails: {
    type: string;
    path: string;
    [key: string]: any;
  };
  privacyLevel: 'None' | 'Private' | 'Organizational' | 'Public';
  credentialDetails: {
    credentialType: string;
    singleSignOnType: 'None' | 'OAuth2' | 'Windows';
    connectionEncryption: 'NotEncrypted' | 'Encrypted';
    skipTestConnection: boolean;
    [key: string]: any;
  };
  description?: string;
  gatewayId?: string;
}

export interface UpdateConnectionRequest {
  displayName?: string;
  connectivityType?: 'ShareableCloud' | 'OnPremisesGateway' | 'VirtualNetworkGateway';
  connectionDetails?: {
    type?: string;
    path?: string;
    [key: string]: any;
  };
  privacyLevel?: 'None' | 'Private' | 'Organizational' | 'Public';
  credentialDetails?: {
    credentialType?: string;
    singleSignOnType?: 'None' | 'OAuth2' | 'Windows';
    connectionEncryption?: 'NotEncrypted' | 'Encrypted';
    skipTestConnection?: boolean;
    [key: string]: any;
  };
  description?: string;
  gatewayId?: string;
}

export interface ListConnectionsResponse {
  value: Connection[];
  continuationToken?: string;
  continuationUri?: string;
}

// ============================
// External Data Shares Types
// ============================

/**
 * External Data Share for sharing data
 * Based on: https://learn.microsoft.com/en-us/rest/api/fabric/core/external-data-shares-provider
 */
export interface ExternalDataShare {
  id: string;
  paths: string[];
  creatorPrincipal: Principal;
  recipient: ExternalDataShareRecipient;
  status: ExternalDataShareStatus;
  expirationTimeUtc: string;
  workspaceId: string;
  itemId: string;
  invitationUrl: string;
  acceptedByTenantId?: string;
}

/**
 * External Data Share Recipient information
 */
export interface ExternalDataShareRecipient {
  userPrincipalName: string;
  tenantId?: string;
}

/**
 * The status of a given external data share
 */
export type ExternalDataShareStatus = 'Pending' | 'Active' | 'Revoked' | 'InvitationExpired';

/**
 * Request to create an External Data Share
 */
export interface CreateExternalDataShareRequest {
  paths: string[];
  recipient: ExternalDataShareRecipient;
}

/**
 * External data share invitation details
 */
export interface ExternalDataShareInvitationDetails {
  pathsDetails: ExternalDataSharePathDetails[];
  providerTenantDetails: ExternalDataShareProviderTenantDetails;
}

/**
 * Details of a path that was shared as part of external data sharing
 */
export interface ExternalDataSharePathDetails {
  name: string;
  pathId: string;
  type: ExternalDataSharePathType;
}

/**
 * The type of a path in an external data share
 */
export type ExternalDataSharePathType = 'Folder' | 'Table';

/**
 * External data share's provider tenant details
 */
export interface ExternalDataShareProviderTenantDetails {
  displayName: string;
  tenantId: string;
  verifiedDomainName: string;
}

/**
 * The request payload for accepting an external data share invitation
 */
export interface AcceptExternalDataShareInvitationRequest {
  itemId: string;
  payload: ShortcutCreationPayload;
  providerTenantId: string;
  workspaceId: string;
}

/**
 * Request payload for shortcut creation
 */
export interface ShortcutCreationPayload {
  createShortcutRequests: CreateExternalDataShareShortcutRequest[];
  path: string;
  payloadType: 'ShortcutCreation';
}

/**
 * Definitions for creating an external data share shortcut
 */
export interface CreateExternalDataShareShortcutRequest {
  pathId: string;
  shortcutName: string;
}

/**
 * The response for accepting an external data share invitation
 */
export interface AcceptExternalDataShareInvitationResponse {
  value: ExternalDataShareShortcutInfo[];
}

/**
 * Information about a shortcut that was created by accepting an external data share invitation
 */
export interface ExternalDataShareShortcutInfo {
  itemId: string;
  name: string;
  path: string;
  workspaceId: string;
}

// Tags Types
export interface Tag {
  id: string;
  name: string;
  description?: string;
  color: string;
}

export interface Tags {
  value: Tag[];
  continuationToken?: string;
  continuationUri?: string;
}

export interface ApplyTagsRequest {
  tags: {
    id: string;
  }[];
}

export interface UnapplyTagsRequest {
  tags: {
    id: string;
  }[];
}

// OneLake Data Access Security Types
export interface DataAccessRoles {
  value: DataAccessRole[];
  continuationToken?: string;
  continuationUri?: string;
}

// Gateway Types
export type GatewayType = 'OnPremises' | 'OnPremisesPersonal' | 'VirtualNetwork';
export type LoadBalancingSetting = 'Failover' | 'DistributeEvenly';
export type GatewayRole = 'Admin' | 'ConnectionCreatorWithResharing' | 'ConnectionCreator';

export interface PublicKey {
  exponent: string;
  modulus: string;
}

export interface VirtualNetworkAzureResource {
  subscriptionId: string;
  resourceGroupName: string;
  virtualNetworkName: string;
  subnetName: string;
}

// Base Gateway interface
export interface BaseGateway {
  id: string;
  type: GatewayType;
}

export interface OnPremisesGateway extends BaseGateway {
  type: 'OnPremises';
  displayName: string;
  publicKey: PublicKey;
  version: string;
  numberOfMemberGateways: number;
  loadBalancingSetting: LoadBalancingSetting;
  allowCloudConnectionRefresh: boolean;
  allowCustomConnectors: boolean;
}

export interface OnPremisesGatewayPersonal extends BaseGateway {
  type: 'OnPremisesPersonal';
  publicKey: PublicKey;
  version: string;
}

export interface VirtualNetworkGateway extends BaseGateway {
  type: 'VirtualNetwork';
  displayName: string;
  capacityId: string;
  virtualNetworkAzureResource: VirtualNetworkAzureResource;
  inactivityMinutesBeforeSleep: number;
  numberOfMemberGateways: number;
}

// Union type for all gateway types
export type Gateway = OnPremisesGateway | OnPremisesGatewayPersonal | VirtualNetworkGateway;

// Gateway responses
export interface ListGatewaysResponse {
  value: Gateway[];
  continuationToken?: string;
  continuationUri?: string;
}

// Gateway member types
export interface OnPremisesGatewayMember {
  id: string;
  displayName: string;
  publicKey: PublicKey;
  version: string;
  enabled: boolean;
}

export interface ListGatewayMembersResponse {
  value: OnPremisesGatewayMember[];
  continuationToken?: string;
  continuationUri?: string;
}

// Gateway role assignment types
export interface GatewayRoleAssignment {
  id: string;
  principal: Principal;
  role: GatewayRole;
}

export interface GatewayRoleAssignments {
  value: GatewayRoleAssignment[];
  continuationToken?: string;
  continuationUri?: string;
}

// Gateway creation requests
export interface CreateVirtualNetworkGatewayRequest {
  type: 'VirtualNetwork';
  displayName: string;
  capacityId: string;
  virtualNetworkAzureResource: VirtualNetworkAzureResource;
  inactivityMinutesBeforeSleep: number;
  numberOfMemberGateways: number;
}

// Gateway update requests
export interface UpdateOnPremisesGatewayRequest {
  displayName?: string;
  loadBalancingSetting?: LoadBalancingSetting;
  allowCloudConnectionRefresh?: boolean;
  allowCustomConnectors?: boolean;
}

export interface UpdateVirtualNetworkGatewayRequest {
  displayName?: string;
  inactivityMinutesBeforeSleep?: number;
  numberOfMemberGateways?: number;
}

export interface UpdateGatewayMemberRequest {
  enabled: boolean;
}

// Gateway role assignment requests
export interface AddGatewayRoleAssignmentRequest {
  principal: {
    id: string;
    type: PrincipalType;
  };
  role: GatewayRole;
}

export interface UpdateGatewayRoleAssignmentRequest {
  role: GatewayRole;
}

