import { WorkloadClientAPI } from "@ms-fabric/workload-client";
import { FabricPlatformClient } from "./FabricPlatformClient";
import { SCOPE_PAIRS } from "./FabricPlatformScopes";
import {
  Item,
  CreateItemRequest,
  UpdateItemRequest,
  ItemDefinitionResponse,
  UpdateItemDefinitionRequest,
  MoveItemRequest,
  BulkMoveItemsRequest,
  MovedItems,
  PaginatedResponse,
  AsyncOperationIndicator
} from "./FabricPlatformTypes";
import { LongRunningOperationsClient } from "./LongRunningOperationsClient";

/**
 * API wrapper for Fabric Platform Item operations
 * Provides methods for managing items (reports, datasets, notebooks, etc.)
 * 
 * Based on the official Fabric REST API:
 * https://learn.microsoft.com/en-us/rest/api/fabric/core/items
 * 
 * Uses method-based scope selection:
 * - GET operations use read-only scopes
 * - POST/PUT/PATCH/DELETE operations use read-write scopes
 */
export class ItemClient extends FabricPlatformClient {
  
  constructor(workloadClient: WorkloadClientAPI) {
    // Use scope pairs for method-based scope selection
    // GET operations will use ITEM_READ scopes, other operations will use ITEM scopes
    super(workloadClient, SCOPE_PAIRS.ITEM);
  }

  // ============================
  // Item Management
  // ============================

  /**
   * Returns a list of items from the specified workspace
   * @param workspaceId The workspace ID
   * @param options Optional filters and pagination
   * @param options.continuationToken Token for pagination
   * @param options.type Filter items by type (e.g., 'Lakehouse', 'Environment', 'Notebook')
   * @param options.recursive Include items from subfolders
   * @param options.rootFolderId Filter items within a specific folder
   * @returns Promise<PaginatedResponse<Item>>
   */
  async listItems(
    workspaceId: string,
    options?: {
      continuationToken?: string;
      type?: string;
      recursive?: boolean;
      rootFolderId?: string;
    }
  ): Promise<PaginatedResponse<Item>> {
    let endpoint = `/workspaces/${workspaceId}/items`;
    const params: string[] = [];
    
    if (options?.continuationToken) {
      params.push(`continuationToken=${encodeURIComponent(options.continuationToken)}`);
    }
    if (options?.type) {
      params.push(`type=${encodeURIComponent(options.type)}`);
    }
    if (options?.recursive !== undefined) {
      params.push(`recursive=${options.recursive}`);
    }
    if (options?.rootFolderId) {
      params.push(`rootFolderId=${encodeURIComponent(options.rootFolderId)}`);
    }
    
    if (params.length > 0) {
      endpoint += `?${params.join('&')}`;
    }
    
    return this.get<PaginatedResponse<Item>>(endpoint);
  }

  /**
   * Gets all items from the specified workspace (handles pagination automatically)
   * @param workspaceId The workspace ID
   * @returns Promise<Item[]>
   */
  async getAllItems(workspaceId: string): Promise<Item[]> {
    return this.getAllPages<Item>(`/workspaces/${workspaceId}/items`);
  }

  /**
   * Creates a new item in the specified workspace
   * @param workspaceId The workspace ID
   * @param request CreateItemRequest
   * @returns Promise<Item>
   */
  async createItem(workspaceId: string, request: CreateItemRequest): Promise<Item> {
    return this.post<Item>(`/workspaces/${workspaceId}/items`, request);
  }

  /**
   * Returns properties of the specified item
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @returns Promise<Item>
   */
  async getItem(workspaceId: string, itemId: string): Promise<Item> {
    return this.get<Item>(`/workspaces/${workspaceId}/items/${itemId}`);
  }

  /**
   * Updates the properties of the specified item
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @param request UpdateItemRequest
   * @returns Promise<Item>
   */
  async updateItem(workspaceId: string, itemId: string, request: UpdateItemRequest): Promise<Item> {
    return this.patch<Item>(`/workspaces/${workspaceId}/items/${itemId}`, request);
  }

  /**
   * Deletes the specified item
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @returns Promise<void>
   */
  async deleteItem(workspaceId: string, itemId: string): Promise<void> {
    await this.delete<void>(`/workspaces/${workspaceId}/items/${itemId}`);
  }

  // ============================
  // Item Definition Management
  // ============================

  /**
   * Returns the definition of the specified item
   * This operation can return either an immediate result or a long-running operation
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @param format Optional format parameter
   * @returns Promise<ItemDefinitionResponse | LongRunningOperation>
   */
  async getItemDefinition(
    workspaceId: string,
    itemId: string,
    format?: string
  ): Promise<AsyncOperationIndicator> {
    let endpoint = `/workspaces/${workspaceId}/items/${itemId}/getDefinition`;
    if (format) {
      endpoint += `?format=${encodeURIComponent(format)}`;
    }
    return this.post<AsyncOperationIndicator>(endpoint);
  }

  /**
   * Returns the definition of the specified item with automatic LRO handling
   * This method automatically polls long-running operations until completion
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @param format Optional format parameter
   * @param pollingIntervalMs Polling interval in milliseconds (default: 2000)
   * @param timeoutMs Timeout in milliseconds (default: 300000 - 5 minutes)
   * @returns Promise<ItemDefinitionResponse>
   */
  async getItemDefinitionWithPolling(
    workspaceId: string,
    itemId: string,
    format?: string,
  ): Promise<ItemDefinitionResponse> {
    const response = await this.getItemDefinition(workspaceId, itemId, format);
    // Poll until completion
    const operationsClient = new LongRunningOperationsClient(this.workloadClient);
    return await operationsClient.waitForSuccessAndGetResult<ItemDefinitionResponse>(response);
  }

  /**
   * Updates the definition of the specified item
   * This operation can return either an immediate result or a long-running operation
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @param request UpdateItemDefinitionRequest
   * @returns Promise<void | LongRunningOperation>
   */
  async updateItemDefinition(
    workspaceId: string,
    itemId: string,
    request: UpdateItemDefinitionRequest
  ): Promise<AsyncOperationIndicator> {
    return this.post<AsyncOperationIndicator>(`/workspaces/${workspaceId}/items/${itemId}/updateDefinition`, request);
  }

  /**
   * Updates the definition of the specified item with automatic LRO handling
   * This method automatically polls long-running operations until completion
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @param request UpdateItemDefinitionRequest
   * @param pollingIntervalMs Polling interval in milliseconds (default: 2000)
   * @param timeoutMs Timeout in milliseconds (default: 300000 - 5 minutes)
   * @returns Promise<void>
   */
  async updateItemDefinitionWithPolling(
    workspaceId: string,
    itemId: string,
    request: UpdateItemDefinitionRequest
  ): Promise<void> {
    const response = await this.updateItemDefinition(workspaceId, itemId, request);
    
    // Poll until completion
    const operationsClient = new LongRunningOperationsClient(this.workloadClient);    
    return await operationsClient.waitForSuccessAndGetResult(response);

  }

  /**
   * Moves an item to a folder within the same workspace
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @param request MoveItemRequest
   * @returns Promise<MovedItems>
   */
  async moveItem(workspaceId: string, itemId: string, request: MoveItemRequest): Promise<MovedItems> {
    return this.post<MovedItems>(`/workspaces/${workspaceId}/items/${itemId}/move`, request);
  }

  /**
   * Moves multiple items to a folder within the same workspace
   * @param workspaceId The workspace ID
   * @param request BulkMoveItemsRequest
   * @returns Promise<MovedItems>
   */
  async bulkMoveItems(workspaceId: string, request: BulkMoveItemsRequest): Promise<MovedItems> {
    return this.post<MovedItems>(`/workspaces/${workspaceId}/items/bulkMove`, request);
  }

  // ============================
  // Item Connections
  // ============================

  /**
   * Returns a list of connections used by the specified item
   * @param workspaceId The workspace ID
   * @param itemId The item ID
   * @param continuationToken Token for pagination
   * @returns Promise<any> - Note: Return type depends on connections.json definitions
   */
  async listItemConnections(
    workspaceId: string,
    itemId: string,
    continuationToken?: string
  ): Promise<any> {
    let endpoint = `/workspaces/${workspaceId}/items/${itemId}/connections`;
    if (continuationToken) {
      endpoint += `?continuationToken=${encodeURIComponent(continuationToken)}`;
    }
    return this.get<any>(endpoint);
  }

  // ============================
  // Helper Methods
  // ============================

  /**
   * Gets items by type from the specified workspace
   * @param workspaceId The workspace ID
   * @param itemType The item type to filter by
   * @returns Promise<Item[]>
   */
  async getItemsByType(workspaceId: string, itemType: string): Promise<Item[]> {
    const allItems = await this.getAllItems(workspaceId);
    return allItems.filter(item => item.type === itemType);
  }

  /**
   * Gets items in a specific folder
   * @param workspaceId The workspace ID
   * @param folderId The folder ID
   * @returns Promise<Item[]>
   */
  async getItemsInFolder(workspaceId: string, folderId: string): Promise<Item[]> {
    const allItems = await this.getAllItems(workspaceId);
    return allItems.filter(item => item.folderId === folderId);
  }

  /**
   * Searches for items by display name
   * @param workspaceId The workspace ID
   * @param searchTerm The search term to match against display names
   * @param caseSensitive Whether the search should be case sensitive (default: false)
   * @returns Promise<Item[]>
   */
  async searchItemsByName(
    workspaceId: string,
    searchTerm: string,
    caseSensitive: boolean = false
  ): Promise<Item[]> {
    const allItems = await this.getAllItems(workspaceId);
    const searchPattern = caseSensitive ? searchTerm : searchTerm.toLowerCase();
    
    return allItems.filter(item => {
      const itemName = caseSensitive ? item.displayName : item.displayName.toLowerCase();
      return itemName.includes(searchPattern);
    });
  }

  /**
   * Creates multiple items in batch
   * @param workspaceId The workspace ID
   * @param requests Array of CreateItemRequest
   * @returns Promise<Item[]>
   */
  async createItemsBatch(workspaceId: string, requests: CreateItemRequest[]): Promise<Item[]> {
    const createdItems: Item[] = [];
    
    for (const request of requests) {
      try {
        const item = await this.createItem(workspaceId, request);
        createdItems.push(item);
      } catch (error) {
        console.error(`Failed to create item ${request.displayName}:`, error);
        // Continue with other items even if one fails
      }
    }
    
    return createdItems;
  }
}