import React from "react";
import { PageProps } from "../../App";
import {
  Ribbon,
  createSaveAction,
  createSettingsAction,
} from "../../components/ItemEditor";

interface K4ModelItemRibbonProps extends PageProps {
  viewContext: any;
  isSaveButtonEnabled: boolean;
  saveItemCallback: () => Promise<void>;
  openSettingsCallback: () => Promise<void>;
}

export function K4ModelItemRibbon({
  isSaveButtonEnabled,
  saveItemCallback,
  openSettingsCallback,
}: K4ModelItemRibbonProps) {
  return (
    <Ribbon
      homeToolbarActions={[
        createSaveAction({ disabled: !isSaveButtonEnabled, onClick: saveItemCallback }),
        createSettingsAction({ onClick: openSettingsCallback }),
      ]}
    />
  );
}
