import React from 'react';
import { useDispatch, useSelector } from "react-redux";
import { Field, Input, Button } from '@fluentui/react-components';
import { PanelRightExpand20Regular } from '@fluentui/react-icons';
import { RootState } from "../Store/Store";
import { setLocalSharedStateMessage } from "../Store/actionDialogSlice";
import { callDialogOpen } from "../../../controller/DialogController";
import { SharedState } from "../../../App";
import "../../Playground.scss";
import { TabContentProps } from '../ClientSDKPlaygroundModel';


export function SharedStateExample(props: TabContentProps) {
    const { workloadClient, sampleWorkloadName } = props;
    const dispatch = useDispatch();
    const sharedState = workloadClient.state.sharedState as SharedState;
    const localSharedStateMessage = useSelector(
        (state: RootState) => state.actionDialog.sharedStateMessage
    );

    async function onCallSharedStatePage() {
        sharedState.message = localSharedStateMessage;

        await callDialogOpen(
            workloadClient,
            sampleWorkloadName,
            '/playground-shared-state-page',
            360 /* width */,
            165 /* height */,
            false /* hasCloseButton */);

        if (localSharedStateMessage != sharedState.message) {
            dispatch(setLocalSharedStateMessage(localSharedStateMessage));
        }
    }

    return (
        <div className="section">
            <Field
                label="Shared State"
                orientation="horizontal"
                className="field"
            >
                <Input
                    size="small"
                    placeholder="Message"
                    value={localSharedStateMessage}
                    onChange={(e) => dispatch(setLocalSharedStateMessage(e.target.value))}
                    data-testid="shared-state-input"
                />
            </Field>
            <Button
                appearance="primary"
                icon={<PanelRightExpand20Regular />}
                onClick={onCallSharedStatePage}
            >
                Open Shared State Page
            </Button>
        </div>
    );
};